# Decomposition Lenses — Membership

Reading boards over the 78. The 4×19 is an elemental partition. The 7×11 and 11×7
are **one forced grid in two orientations** — planet-first (Planetary Court) and
sephira-first (Sefirah Court) — per PAT-610. No lens is chart-derived; the chart
enters only through the triangle's reading edges (below).

---

## 4×19 — Elemental (complete)

Four elemental groups of nineteen: each = full suit (Ace + pips 2–10 + 4 courts = 14)
+ **5 Majors** (3 zodiacal of the element's signs, 1 elemental Major, 1 planetary
Major). **Sun (19)** and **High Priestess / Moon (2)** are held out as the two lights
framing the deck. 4×19 = 76, + Sun + Moon = 78.

Planetary-Major seats follow the planet→element rule (Mars/Fire, Jupiter/Water,
Mercury/Air, Venus/Earth) — this can differ from a card's intrinsic element (e.g.
Wheel of Fortune's node reads Earth, but it seats as Water's planetary Major under
Jupiter, per your "Fortune for Jupiter").

| Element | Suit | 3 Zodiacal Majors | Elemental Major | Planetary Major |
|---|---|---|---|---|
| **Fire** | Wands (14) | Emperor (Aries), Strength (Leo), Temperance (Sagittarius) | Judgement | Tower (Mars) |
| **Water** | Chalices (14) | Chariot (Cancer), Death (Scorpio), The Moon (Pisces) | The Hanged Man | Wheel of Fortune (Jupiter) |
| **Air** | Swords (14) | Lovers (Gemini), Justice (Libra), The Star (Aquarius) | The Fool | The Magician (Mercury) |
| **Earth** | Pentacles (14) | Hierophant (Taurus), Hermit (Virgo), The Devil (Capricorn) | The World | The Empress (Venus) |

Held out: **The Sun (19)**, **The High Priestess / Moon (2)** — first division and
final prime, the frame rather than the contents.

---

## 7×11 — Planetary Court (complete; the Planetary Lords orientation)

Seven classical planets, 11 cards each; **the Fool held apart**. The planet-first
orientation of the forced grid: each column read as one lord's full court —
**the planet's relational resonance**, scored against the subject's chart.

**Closing arithmetic** (verified): five non-luminaries = 3 Majors + 6 Minors + 2
Courts = 11; luminaries = 3 Majors + 3 Minors + 1 Court + 4 Thrones/Aces = 11.

### Majors — 3 per planet (own trump + domicile-sign trumps)

| Planet | Majors |
|---|---|
| Mars | Tower (own), Emperor (Aries), Death (Scorpio) |
| Venus | Empress (own), Hierophant (Taurus), Justice (Libra) |
| Mercury | Magician (own), Lovers (Gemini), Hermit (Virgo) |
| Jupiter | Wheel of Fortune (own), Temperance (Sagittarius), The Moon (Pisces) |
| Saturn | World (own), Devil (Capricorn), Star (Aquarius) |
| Sun | Sun (own), Strength (Leo), Judgement (Fire mother) |
| Moon | High Priestess (own), Chariot (Cancer), The Hanged Man (Water mother) |

Sun and Moon rule only one sign each, so own-trump + domicile yields 2 Majors; the
third is the same-element **mother trump** — **hard-set by PAT-610**: a single-sign
ruler generates only one element and *must* annex its mother trump to close its
pillar (Judgement → Sun's Malkuth, Hanged Man → Moon's Keter). The bend is forced,
not a patch; the earlier sect-derivation note is retired. Mercury (Gemini day/air +
Virgo night/earth) is the most regular tree — it never borrows.

### Minors — by Room (triplicity-ascent) ruler (complete, from `decans.md`)

| Planet | Count | Cards |
|---|---|---|
| Mars | 6 | 2·7·9 Wands, 3·5·10 Chalices |
| Jupiter | 6 | 4·6·8 Wands, 4·6·8 Chalices |
| Saturn | 6 | 2·7·9 Pentacles, 3·5·10 Swords |
| Venus | 6 | 3·5·10 Pentacles, 2·7·9 Swords |
| Mercury | 6 | 4·6·8 Pentacles, 4·6·8 Swords |
| Sun | 3 | 3·5·10 Wands |
| Moon | 3 | 2·7·9 Chalices |

### Courts — by domicile ruler of the court's dominant sign (complete)

The 12 Knight/Queen/King courts (Pages are thrones — see Thrones/Aces below). Each
court's **dominant sign** is the in-element sign anchoring its suit's element (the
0–20° majority of its span; Queen = cardinal, Knight = fixed, King = mutable — see
`mbti-majestic.md`), mapped to that sign's domicile ruler:

| Planet | Courts (dominant sign) |
|---|---|
| Mars | Queen of Wands (Aries), Knight of Chalices (Scorpio) |
| Venus | Queen of Swords (Libra), Knight of Pentacles (Taurus) |
| Mercury | King of Swords (Gemini), King of Pentacles (Virgo) |
| Jupiter | King of Wands (Sagittarius), King of Chalices (Pisces) |
| Saturn | Knight of Swords (Aquarius), Queen of Pentacles (Capricorn) |
| Sun | Knight of Wands (Leo) |
| Moon | Queen of Chalices (Cancer) |

2 each to the five non-luminaries, 1 each to the luminaries = 12.

### Thrones + Aces — Sun and Moon (complete)

Fire + Air (diurnal) → **Sun**; Water + Earth (nocturnal) → **Moon**. Each luminary
takes 2 Thrones + 2 Aces = 4.

- **Sun:** Throne & Ace of Wands (Fire), Throne & Ace of Swords (Air).
- **Moon:** Throne & Ace of Chalices (Water), Throne & Ace of Pentacles (Earth).

---

## 11×7 — Sefirah Court (complete; PAT-610, the transposition)

Eleven Tree stations (10 Sephiroth + Da'ath) × 7 planetary trees = 77, **+ the Fool
apart**. **Not a second board** — the 7×11 transposed: the same placement
re-addressed **sephira-first** (each row a station across the seven trees) instead
of planet-first. Nothing is dealt and nothing is chart-derived: placement is
**forced** by two invariants. Canonical derivation: **PAT-610** ("The 11×7
Derivation: Planetary Grammar Falls Out of the Double-18"). The former chart-derived
"Procession of the Lords" laying is **superseded**.

### Placement (all 77, forced)

| Cards | Station |
|---|---|
| 7 planetary trumps | **Da'ath** of their own tree — the planet its ten minors embody but cannot name |
| 12 zodiac trumps | **Keter / Malkuth** — 10 across the five double-sign planets; Strength (Leo) → Sun's Keter, Chariot (Cancer) → Moon's Malkuth |
| 2 mother trumps | Judgement (Fire) → **Sun's Malkuth**; Hanged Man (Water) → **Moon's Keter** — forced (see 7×11 Majors note) |
| 12 courts (K/Q/Kn) | **Tiphareth** (day sect) / **Yesod** (night sect): 5 planets × 2 sects + Sun-day + Moon-night |
| 4 Thrones / 4 Aces | Thrones → the **Sun's tree**, Aces → the **Moon's**. Throne/Ace of Pentacles anchors the empty central sephira; the other three fill the open side pillar in manifestation order (Wands, Chalices, Swords) |
| 36 pips | the 36 **side-pillar** slots — 6 per non-luminary tree, 3+3 on the luminaries |

The Fool is never placed — the indivisible source, what positions are made of. The
construction closes at exactly 77, proving its own first premise as a byproduct.

### Law 1 — the double-18 (arithmetic, bundles the triples)

Each suit's pips 2–10 admit **exactly two** partitions into sum-18 triples:
**A** {2,6,10} {3,7,8} {4,5,9} · **B** {2,7,9} {3,5,10} {4,6,8}. Any square whose
rows and columns both read 18 must take one partition as rows and the other as
columns. The 18-rule bundles completely but is permutation-blind (eight arrangements
survive it); Law 2 stacks and labels.

|  | Cardinal | Fixed | Mutable |
|---|---|---|---|
| **Depth 0** | 2 | 10 | 6 |
| **Depth 1** | 7 | 3 | 8 |
| **Depth 2** | 9 | 5 | 4 |

Semimagic, not magic: rows + columns lock at 18; diagonals stay free — correctly,
since the Tree mandates pillars and depths, never diagonals. The **broken diagonals
are the signs themselves** — {2,3,4} {5,6,7} {8,9,10}, graded 9 / 18 / 27 (3², 2·3²,
3³); the pure cube rides the mutable signs.

### Law 2 — the dodecatemoria (zodiacal, stacks rows and names columns)

Each decan holds four twelfth-parts, a contiguous arc opening at
(sign position + 4 × decan index) mod 12.

- **Rows disperse.** Each A-triple's arcs open at p, p+4, p+8 — every depth-row is a
  complete zodiac in twelfth-parts. **Depth = the displacement of the home sign's
  run** (0 / 4 / 8 → Depth 0 / 1 / 2; equivalently (decan index − triplicity rank)
  mod 3). The self-anchored run sits at Depth 0 — the supernal end of the pillar.
- **Columns converge.** Each B-triple's arcs open at the *same* sign — the cardinal,
  fixed, or mutable sign of the element. Column labels are **derived, not
  assigned** — and the B-triples are exactly the **Room-lord (triplicity-ascent)
  groups**: column = Room lord = modality.

**Zero residual freedom.** The square is unique from exactly two laws. **Sect is
retired as a uniqueness constraint** — diurnal lightning-flash / nocturnal serpent
directionality and Mercury the ambidextrous tree survive as interpretive layers.
Decan-resolution shadow: the depth-rows project onto the three combs (2-6-10,
3-7-8, 4-5-9), disjoint Latin diagonals tiling all 36 decans.

### The Bands (station dignity)

Each station-row is a **Band** anchored by a planet; in the Sefirah-Court aim, a
planet's **intrinsic dignity** is read by Band. Canonical anchors (diagram,
2026-07-02):

| Band | Anchor |
|---|---|
| **Keter** | **Neptune** |
| **Chokmah** | **Uranus** |
| **Malkuth** | **Pluto** |

These are precisely the three modern-overlay Majors' landing sites in the forced
grid: Hanged Man (Neptune) → Moon's **Keter**; Judgement (Pluto) → Sun's
**Malkuth**; the Fool (Uranus) unplaced, its Tree path terminating at **Chokmah** —
the unplaced source enters the board at Uranus's band. Coheres with the modality
rule: Uranus/Cardinal, Neptune/Fixed, Pluto/Mutable.

⚠️ **Pending confirmation:** the remaining Bands. Presumed the traditional seven —
Binah=Saturn, Chesed=Jupiter, Geburah=Mars, Tiphareth=Sun, Netzach=Venus,
Hod=Mercury, Yesod=Moon — with **Da'ath open** (the tree's own planet, per its
trump seat?). Do **not** assert these in a reading until confirmed.

---

## The triangle — one grid, two aims (replaces the three-board method)

The former scored / dealt / derived displacement method is **retired**. The 7×11 and
11×7 are one placement transposed, each aimed at the birth chart along its own
channel:

- **Birthchart → 7×11** — *Scored by Resonance*: the chart weights the Planetary
  Court by relational resonance (Mars Scoring Engine channel).
- **7×11 → Birthchart** — *Read by Planetary Court*: the relational aim reads back —
  each planet's relational resonance in the life.
- **7×11 → 11×7** — *Placed by Assignment*: the transposition itself; PAT-610 makes
  the assignment forced, so "placed" is literal.
- **11×7 → Birthchart** — *Read by Sefirah Dignity*: the intrinsic aim — each
  planet's intrinsic dignity/resonance read by its station **Band**.

The reading is **stereo**: relational resonance (planetary aim) and intrinsic
dignity (sephirothic aim) as two views of one placement. Kairos is needed only for
these chart edges — never for the lenses themselves.
