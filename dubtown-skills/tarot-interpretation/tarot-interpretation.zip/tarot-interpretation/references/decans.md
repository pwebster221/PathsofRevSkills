# Minor Arcana — Decan Table (Traveler · Room · Home)

Source: live pull from the Esoteric Repository (`MinorArcana`, pips 2–10), verified
against the Mars Scoring Engine canon. This file is authoritative for the Minor
module and feeds the 7×11 lens.

## The reading model — a nested spatial scene

> **The Chaldean Decan Ruler travels as a Visitor through the Egyptian
> (Triplicity-Ascent) Ruler's Room, within the House Ruler's Home.**

Three planetary layers, one inside the next — **all three always live**:

- **Traveler — Chaldean decan ruler.** The secondary, *time-bound* system
  (descending planetary speeds; the rhythm of the hours, the progression of time).
  The moving guest passing through this decan now.
  Edge: `(:MinorArcana)-[:COUNTER_RULED_BY]->(:HeavenlyBody)`.
- **Room — Egyptian / triplicity-ascent ruler.** The default, *eternal* system —
  the geometrically perfect rulership. It owns the room the Traveler enters: the
  fixed local environment. This is what the Mars Scoring Engine scores on and what
  the 7×11 lens reads.
  Edge: `(:MinorArcana)-[:RULED_BY_DECAN]->(:HeavenlyBody)`.
- **Home — the house ruler.** The natural lord of the whole-sign house the card's
  sign occupies in the querent's chart. The only personal layer — the ascendant
  sets it. Computed, never stored on the card.

**Universal vs. personal.** Traveler and Room are fixed structure, identical for
every querent. Home rotates with the ascendant. On the **neutral chart (Aries
rising)** house numbering re-aligns with the zodiac, the house lord collapses onto
the sign's domicile lord, and the triad reads **decan · triplicity · domicile**.

### Computing Home

Whole-sign: house number = ((sign index − ascendant sign index) mod 12) + 1.
Natural lords of the **ordinal** houses:

| House | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Lord | Mars | Venus | Mercury | Moon | Sun | Mercury | Venus | Mars | Jupiter | Saturn | Saturn | Jupiter |

**Paul's chart — Gemini rising** (default when the querent is Paul):

| Sign | House | Home lord |
|---|---|---|
| Gemini | 1 | Mars |
| Cancer | 2 | Venus |
| Leo | 3 | Mercury |
| Virgo | 4 | Moon |
| Libra | 5 | Sun |
| Scorpio | 6 | Mercury |
| Sagittarius | 7 | Venus |
| Capricorn | 8 | Mars |
| Aquarius | 9 | Jupiter |
| Pisces | 10 | Saturn |
| Aries | 11 | Saturn |
| Taurus | 12 | Jupiter |

If the querent's ascendant is unknown, use the neutral Aries chart (Home collapses
to the domicile lord) and say so.

## Repository edges (correct by design)

- `RULED_BY_DECAN` → the **Room** (Egyptian / triplicity-ascent). Canonical scorer.
- `COUNTER_RULED_BY` → the **Traveler** (Chaldean).
- ⚠️ The node property `astro_planetary_ruler` mirrors the **Chaldean / Traveler**
  value. Resolve the Room from the `RULED_BY_DECAN` **edge**, never that property.

## Sign progression

Each suit runs its three signs, three pips each, beginning with the suit's cardinal
sign: Wands → Aries/Leo/Sagittarius; Chalices → Cancer/Scorpio/Pisces; Swords →
Libra/Aquarius/Gemini; Pentacles → Capricorn/Taurus/Virgo.

## Table

Grammar reminder — **Traveler (Chaldean) moves through the Room (triplicity-ascent)
within the Home (house lord, computed above) · sign = the field · Enneagram type =
the situation.**

| Card | Suit | Pip | Sign | Traveler (Chaldean) | Room (triplicity-ascent) | Enneagram |
|---|---|---|---|---|---|---|
| Two of Wands | Wands | 2 | Aries | Mars | Mars | 2 |
| Three of Wands | Wands | 3 | Aries | Sun | Sun | 3 |
| Four of Wands | Wands | 4 | Aries | Venus | Jupiter | 4 |
| Five of Wands | Wands | 5 | Leo | Saturn | Sun | 5 |
| Six of Wands | Wands | 6 | Leo | Jupiter | Jupiter | 6 |
| Seven of Wands | Wands | 7 | Leo | Mars | Mars | 7 |
| Eight of Wands | Wands | 8 | Sagittarius | Mercury | Jupiter | 8 |
| Nine of Wands | Wands | 9 | Sagittarius | Moon | Mars | 9 |
| Ten of Wands | Wands | 10 | Sagittarius | Saturn | Sun | 1 |
| Two of Chalices | Chalices | 2 | Cancer | Venus | Moon | 2 |
| Three of Chalices | Chalices | 3 | Cancer | Mercury | Mars | 3 |
| Four of Chalices | Chalices | 4 | Cancer | Moon | Jupiter | 4 |
| Five of Chalices | Chalices | 5 | Scorpio | Mars | Mars | 5 |
| Six of Chalices | Chalices | 6 | Scorpio | Sun | Jupiter | 6 |
| Seven of Chalices | Chalices | 7 | Scorpio | Venus | Moon | 7 |
| Eight of Chalices | Chalices | 8 | Pisces | Saturn | Jupiter | 8 |
| Nine of Chalices | Chalices | 9 | Pisces | Jupiter | Moon | 9 |
| Ten of Chalices | Chalices | 10 | Pisces | Mars | Mars | 1 |
| Two of Swords | Swords | 2 | Libra | Moon | Venus | 2 |
| Three of Swords | Swords | 3 | Libra | Saturn | Saturn | 3 |
| Four of Swords | Swords | 4 | Libra | Jupiter | Mercury | 4 |
| Five of Swords | Swords | 5 | Aquarius | Venus | Saturn | 5 |
| Six of Swords | Swords | 6 | Aquarius | Mercury | Mercury | 6 |
| Seven of Swords | Swords | 7 | Aquarius | Moon | Venus | 7 |
| Eight of Swords | Swords | 8 | Gemini | Jupiter | Mercury | 8 |
| Nine of Swords | Swords | 9 | Gemini | Mars | Venus | 9 |
| Ten of Swords | Swords | 10 | Gemini | Sun | Saturn | 1 |
| Two of Pentacles | Pentacles | 2 | Capricorn | Jupiter | Saturn | 2 |
| Three of Pentacles | Pentacles | 3 | Capricorn | Mars | Venus | 3 |
| Four of Pentacles | Pentacles | 4 | Capricorn | Sun | Mercury | 4 |
| Five of Pentacles | Pentacles | 5 | Taurus | Mercury | Venus | 5 |
| Six of Pentacles | Pentacles | 6 | Taurus | Moon | Mercury | 6 |
| Seven of Pentacles | Pentacles | 7 | Taurus | Saturn | Saturn | 7 |
| Eight of Pentacles | Pentacles | 8 | Virgo | Sun | Mercury | 8 |
| Nine of Pentacles | Pentacles | 9 | Virgo | Venus | Saturn | 9 |
| Ten of Pentacles | Pentacles | 10 | Virgo | Mercury | Venus | 1 |

## Room-lord distribution (feeds the 7×11 lens)

Counting the canonical **Room** (triplicity-ascent) rulers across the 36 pips:

| Planet | Count | Cards |
|---|---|---|
| Mars | 6 | 2·7·9 Wands, 3·5·10 Chalices |
| Jupiter | 6 | 4·6·8 Wands, 4·6·8 Chalices |
| Saturn | 6 | 2·7·9 Pentacles, 3·5·10 Swords |
| Venus | 6 | 3·5·10 Pentacles, 2·7·9 Swords |
| Mercury | 6 | 4·6·8 Pentacles, 4·6·8 Swords |
| Sun | 3 | 3·5·10 Wands |
| Moon | 3 | 2·7·9 Chalices |

6 each to the five non-luminaries, 3 each to the luminaries = 36. This is exactly
the Minor contribution the 7×11 planetary-lords lens requires. These Room-lord
groups are also the **B-triples of the double-18** — the columns of the 11×7
semimagic square (see `lenses.md`, PAT-610).
