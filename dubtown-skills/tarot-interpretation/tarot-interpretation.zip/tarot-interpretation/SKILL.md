---
name: tarot-interpretation
description: >-
  Interpret tarot cards through Paul's correspondence stack for The 78 (not generic
  Rider-Waite), reading from bundled self-contained tables — no live lookup.
  Per-arcana grammar: Major by the Generative Principle + Kabbalah; Majestic by the
  MBTI generator (Thrones/Court/Aces); Minor by the Traveler·Room·Home triad
  (Chaldean visitor in the triplicity-ascent ruler's room within the house lord's
  home) + sign + Enneagram. Optionally places a reading in a decomposition lens
  (4×19 elemental; 7×11 Planetary Court / 11×7 Sefirah Court — one forced grid,
  transposed) and scores resonance via the Mars Scoring Engine. Use whenever
  the user supplies a card, spread, or derived reading to interpret in their system —
  e.g. "interpret this card", "read these cards", "what does X of Chalices mean in my
  system", "read this spread", "interpret by lot/by element", "score this reading".
  INTERPRET ONLY — never draw, deal, or randomly select a card; cards are
  user-supplied or deterministically derived.
---

# Tarot Interpretation (The 78)

## What this does

Takes a card, a positional spread, or a full derived reading and interprets it
through Paul's correspondence stack — the three-arcana architecture of The 78,
not stock card meanings. Every correspondence is listed in the bundled `references/`
tables, so interpretation needs **no live database lookup** — read the tables
directly. Flow: **resolve from references → read each card → synthesize → (lens
placement) → (resonance score) → persist.**

The user may ask for a single card or a whole spread, with or without a lens, with
or without scoring. Run only what is asked.

## Sources

- **`references/` (bundled, authoritative).** All correspondences live here and are
  the source of truth for interpretation: `majors.md` (Major attributions),
  `generative-principle.md` (the 1–21 number layer), `mbti-majestic.md` (the Majestic
  generator), `decans.md` (the 36 Minors), `lenses.md` (4×19 / 7×11 / 11×7). Read
  these directly — no query needed to interpret.
- **repository** (Neo4j) — used only for **persistence** of a reading and optional
  **verification/refresh** of the tables. Not consulted during ordinary
  interpretation. Reading edges: `THROUGH_LENS`, `DREW_CARD`, `DOMAIN_CARD`,
  `PLANETARY_CARD`.
- **Mars Scoring Engine** — optional. Scores a card or reading's resonance against
  supplied text. It scores on **triplicity-ascent** decan lords.
- **kairos-mcp** — required only when a board is **read against a natal chart**
  (the triangle's chart edges — see `lenses.md`); every lens itself is fixed
  structure.

## Standing rules

1. **Interpret only — never draw.** This skill never randomizes, deals, shuffles,
   or selects a card. Cards arrive either user-supplied or **deterministically
   derived** by another system (a chart cast, a releasing period, Sacred Journey).
   Derived single cards are valid but rare. If asked to "draw" or "pull" a random
   card, decline and ask for the card(s) or the derivation source.
2. **The bundled tables are authoritative.** Interpret from `references/`; do not
   query the Repository to look up a correspondence. The Repository is consulted only
   to persist a reading or to verify/refresh the tables on request.
3. **Verify before writing.** Before any Cypher *write* (persistence), run read
   queries to confirm exact node names, labels, and edge types. No exceptions. And
   never invent a correspondence that isn't in the tables — if something's missing,
   say so rather than guess.
4. **Water suit is Chalices** — everywhere, including any historical/derived input
   that arrives as "Cups." Normalize silently.
5. **Minor rulers — Traveler · Room · Home** (all three always live). **Traveler**
   = Chaldean decan ruler, the time-bound visitor. **Room** = Egyptian /
   triplicity-ascent ruler, the eternal chamber — canonical: what the Mars engine
   scores and the 7×11 lens reads. **Home** = the natural lord of the whole-sign
   house the card's sign occupies for the querent's ascendant — the only personal
   layer (Aries rising collapses it to the domicile lord; Paul = Gemini rising).
   Chaldean is not an off-by-default alternate; it is the Traveler in every
   Minor reading.
6. **Majestic is a generator, not a lookup.** Derive a court/throne card's MBTI
   from the two binaries (§Majestic). Do not read the type off a stored table as
   the primary act; the stored value is a cache to cross-check against, not the
   source of truth.
7. **Time is Unix epoch seconds as a node property** — never an edge property; no
   `TimeFrame` nodes; no Neo4j Aura for writes (Python + driver).

**All correspondences are listed in `references/`. Read them directly to interpret —
no live query is needed.**

---

## Resolving a card

Normalize the name (Cups → Chalices), then classify the tier from the name and read
that card's row from the matching table — no query:

- **Major** (The Fool … The World) → `references/majors.md` + `generative-principle.md`
- **Majestic** (any Page/Knight/Queen/King/Ace) → `references/mbti-majestic.md`
- **Minor** (pips Two–Ten of a suit) → `references/decans.md`

Then route to the matching module below.

---

## Major module — 22 (0 + 21)

The Major is the **cosmological / archetypal** layer. The Fool is **0**, the
generative precondition standing outside the count; the structure proper is the
21 = 3 × 7.

**Resolve** from `references/majors.md` (element, sign/planet, Hebrew letter, Tree
path, stage of the path) and `references/generative-principle.md` (the number's
prime/composite status, factorization, pillar(s), septenary role).
- **Prime vs composite.** 9 emergent primes (the Enneagram-shaped set) read as
  *irreducible generative acts*. 12 composites (the Zodiac-shaped set) read as
  **trinity-operations**: smaller factor = **Operator**, larger = **Substance**,
  product = **Result**, mapped to Cardinal · Fixed · Mutable. Squares are
  self-action.
- **Generate / Produce rhythm.** Odd→Even = Generate, Even→Odd = Produce.
- **Pillar membership** (four pillars by base prime, per `references/generative-principle.md`):
  Mind (×2, the evens), Soul (×3), Man (×5), Divine (×7). Dual members (e.g. 6/12/18
  = Mind∧Soul, 21 = Soul∧Divine) read as reinforcement.
- **Septenary role.** Operator (1–7), Substance (8–14), Result (15–21).

**Then layer:** Hebrew letter, Tree path, stage of the path, and astrology (sign
card → 1 sign; planetary card → its domicile sign(s); elemental card —
Fool/Hanged Man/Judgement — → all 3 signs of its element).

**Grammar:** read the card as *a structural operation in the deck's self-generation*
— what it produces and how — located on its pillar(s) and septenary, then deepened by
its Kabbalah and astrology. The Fool, when present, is read as the precondition, not
a step.

---

## Majestic module — 20 (4 Thrones + 12 Court + 4 Aces)

The **mental-structures** layer. Internal split:

- **Thrones** — the 4 **Pages**, the *seasonal thrones*: each is seated at the
  cross-quarter festival at its season's **height** (Wands = Lammas, Chalices =
  Samhain, Pentacles = Beltane, Swords = Candlemas).
- **Court** — **Knights, Queens, Kings** (12), the working psyches. **Queens and
  Kings hold the solstices and equinoxes.**
- **Aces** — the 4 pure cognitive-function pairs (Ni+Ne, Fi+Fe, Ti+Te, Si+Se),
  standing as the **culmination above their throne** — the function whole, before
  it stacks.

Three independent layers sit on each Majestic card and must not be conflated: the
**cognitive** layer (the MBTI generator below), the **seasonal** layer (Sabbats,
above), and the **elemental** layer (inner = suit element, outer = rank element).
All three are true at once.

**Suit → function:** Wands/Intuition · Chalices/Feeling · Swords/Thinking ·
Pentacles/Sensing.

**MBTI generator (derive, do not look up).** For a Throne or Court card, the type
is fixed by two orthogonal binaries:
1. **Dominant attitude** — extraverted (♂) or introverted (♀). ♂ → Knight/King;
   ♀ → Page/Queen.
2. **Auxiliary element vs suit element** — *opposing* pair (Fire/Water, Air/Earth)
   → the youth/conflict ranks **Page/Knight**; *complementary* pair (Fire/Air,
   Water/Earth) → the experienced/harmony ranks **Queen/King**.

The 2×2 over those binaries yields the four courts of a suit uniquely. Worked
example (Wands = Fire = Intuition dominant): Page = INFJ (Ni; aux Fe→Water,
opposing), Knight = ENFP (Ne; aux Fi→Water, opposing), Queen = INTJ (Ni; aux
Te→Air, complementary), King = ENTP (Ne; aux Ti→Air, complementary).

**Resolve** the full type, cognitive stack, seasonal seat, and elemental pair from
`references/mbti-majestic.md` (which lists all 16 courts + 4 Aces). The table is the
generator's cached output — if a derivation ever disagrees with it, trust the
derivation and flag the row.

**Grammar:** read as *a mind shaped around the suit's function* — the cognitive
stack in motion. A **Throne/Page** adds its seasonal seat; an **Ace** is read as
the function in its undivided culmination, not as a person.

---

## Minor module — 36 (pips 2–10)

The **patterns-of-behavior** layer. Nine pips per suit.

The pips are read as a **nested spatial scene**:

> **The Chaldean Decan Ruler travels as a Visitor through the Egyptian
> (Triplicity-Ascent) Ruler's Room, within the House Ruler's Home.**

**Resolve** from `references/decans.md`: sign, **Traveler** (Chaldean), **Room**
(triplicity-ascent), Enneagram type — then **compute Home**: the whole-sign house
the card's sign occupies for the querent's ascendant → the natural lord of that
ordinal house (tables in `decans.md`). Paul's ascendant is **Gemini**; if the
querent's rising is unknown, use the neutral Aries chart (Home collapses to the
sign's domicile lord) and say so.

**Grammar (the scene + the situation):**
- **Traveler** — Chaldean ruler: the time-bound actor, who is passing through now.
- **Room** — triplicity-ascent ruler: the eternal local environment, the chamber's
  owner. (What the Mars engine scores.)
- **Home** — house lord: whose domain the whole scene sits in — the personal layer.
- **Sign** — the field. **Enneagram type = situation** — pip number: 2→Type 2 …
  9→Type 9, **10→Type 1** (return to source); center → modality: Heart (2,3,4) =
  Cardinal, Head (5,6,7) = Fixed, Body (8,9,1) = Mutable.

Read as: *this visitor, moving through this chamber, inside this domain — in this
field, facing this situation.* **Doubled signatures** (one planet holding two of
the three slots) are load-bearing — always name them. The pip's position in its
suit's 2→10 ascent (the suit's function climbing its territory) gives the
developmental register.

---

## Decomposition lenses (optional)

A reading can be placed on the elemental partition (4×19) or on the planetary grid
in either orientation (7×11 / 11×7 — **one forced placement, transposed**). These
are reading **boards**, not card meanings. Full membership is in
`references/lenses.md`. Use only when asked ("read by element / by lot / on the
Tree").

- **4×19 — Elemental** (complete). Four elements × 19 (suit of 14 + 5 Majors: 3
  zodiacal, 1 elemental, 1 planetary). Sun (19) and High Priestess/Moon (2) held out
  as the frame. Read a card by its **elemental home**.
- **7×11 — Planetary Court** (complete; the Planetary Lords orientation). Seven
  planets × 11, Fool apart — planet-first: each lord's full court, the planet's
  **relational resonance** against the chart. Membership in `lenses.md`: Majors by
  own + domicile-sign trumps (mother trumps **hard-set** per PAT-610: Judgement→Sun,
  Hanged Man→Moon), Minors by Room (triplicity-ascent) ruler, Courts by
  dominant-sign domicile ruler, Thrones→Sun / Aces→Moon.
- **11×7 — Sefirah Court** (complete; **PAT-610**). **The same grid transposed** —
  sephira-first: 10 Sephiroth + Da'ath × 7 trees, Fool apart. Placement is *forced*
  by two invariants (the double-18 bundles the triples; the dodecatemoria stack the
  depths and name the columns); nothing is dealt or chart-derived — the old
  Procession laying is superseded. Station **Bands** carry intrinsic dignity
  (Keter=Neptune, Chokmah=Uranus, Malkuth=Pluto; rest pending). Full derivation in
  `lenses.md`.

**The triangle (one grid, two aims).** The old three-board displacement method is
**retired**. Birthchart → 7×11 *Scored by Resonance* (Mars engine) and back *Read by
Planetary Court* — the relational aim; 7×11 → 11×7 *Placed by Assignment* — the
forced transposition; 11×7 → Birthchart *Read by Sefirah Dignity* — the intrinsic
aim, by Band. The reading is **stereo**: relational and intrinsic views of one
placement.

---

## Interpretation modes

- **Single card** — resolve → module grammar → one tight reading.
- **Spread** — interpret each card in its named position, then a synthesis that
  reads the cards as one dialogue (not isolated blurbs). Note cross-arcana
  resonances (e.g. a Minor's planet echoing a Major in the spread).
- **Resonance score** (optional) — if the user gives text (a question, a journal
  entry, a situation), call `Mars Scoring Engine: classify_text` and report how the
  card(s) score against it. Never narrate engine internals.
- **Lens placement** (optional) — locate the reading on a chosen board.

---

## Persistence

Persist only when the user wants the reading kept.

1. **Verify schema first** — inspect `:Interpretation` / `:Reading` shape and edge
   types before writing:
   ```cypher
   MATCH (r:Reading)-[e]->(x) RETURN type(e), labels(x) LIMIT 15
   ```
2. Create the reading node with Unix-time node props; attach each card with
   `DREW_CARD` (per position) and the lens with `THROUGH_LENS` if one was used.
   All people are `:User` nodes; role is set by edge type (`FOR_USER` = submitter;
   `READER`/`QUERENT` only when someone else fills that role).
3. Python + Neo4j driver, not Aura.

---

## Output Format

```
# Reading — <card / spread name>

## Cards
<per card: name · tier · resolved correspondences>

## Reading
<per-card interpretation via the module grammar>

## Synthesis
<the spread read as one, cross-resonances noted>     # spreads only

## Lens — <4×19 | 7×11 | 11×7>                        # if requested
<placement + what the board adds>

## Resonance                                          # if scored
<Mars scores vs the supplied text>

## Persistence
<:Reading node id, lens edge, card edges>             # if persisted
```

Lead with the resolved correspondences, keep interpretation specific to the cards
in front of you, and let the per-arcana grammar — not generic meanings — carry the
read.

---

## references/

The bundled tables, authoritative and self-contained:

- **`majors.md`** — Major attribution sheet (element, sign/planet, Hebrew letter,
  Tree path, stage). No Hermetic-principle layer (retired; the Generative Principle
  replaces it).
- **`generative-principle.md`** — numbers 1–21: prime/composite, factorization,
  pillars, septenary roles (from Linear PAT-212–232).
- **`mbti-majestic.md`** — the Majestic generator + the 16 courts and 4 Aces, with
  the seasonal and inner/outer-element layers.
- **`decans.md`** — the 36 Minors: sign, **Traveler** (Chaldean), **Room**
  (triplicity-ascent), the **Home** computation (house-lord tables + ascendant,
  Gemini default for Paul, Aries collapse), Enneagram.
- **`lenses.md`** — 4×19 (complete); 7×11 / 11×7 (complete — **one forced grid, two
  orientations**, per PAT-610); the **triangle** reading method; the **Bands**.

All lenses are fixed structure; no lens needs a chart. The chart enters only through
the triangle's reading edges (*Scored by Resonance / Read by Planetary Court / Read
by Sefirah Dignity*). Mother-trump seats are hard-set by PAT-610 (Judgement→Sun's
Malkuth, Hanged Man→Moon's Keter); the sect-derivation note is retired. **Open:**
the Band table beyond the three outer anchors (flagged in `lenses.md`) — do not
assert unconfirmed Bands in a reading.
